### SocialX a community-driven social media platform

Welcome to the SocialX source code repository!
SocialX is a community-driven social media platform allowing users to publish every form of creative content. We are opening a new chapter of how humans share snapshots of their lives and interact with each other.

### Releases

https://github.com/SocialXNetwork/socialx_react_native/releases

### Core Features of the SocialX-App:
 
* Distributed social media network via a peer-to-peer network
*  Giving ownership of content back to social media users
*  Integrating freedom of speech as a core principle in our platform
*  Building a reward system where contributors are rewarded for sharing quality content.
*  Building a unique ad system which gives most of its revenue back to the community.
*  Enables you to take license management into your own hand

### SocialX Database System

Database peers save the data from SocialX and distribute it to the users. In the database peers we save e.g. user data, post data and comments.

Guide how to run a SocialX database peer:  https://medium.com/@socialx/socialx-database-system-2c8910a110bb


### Whitepaper

https://socialx.network/whitepaper/

### Contact us

https://socialx.network/

https://medium.com/@socialx

https://t.me/socialx

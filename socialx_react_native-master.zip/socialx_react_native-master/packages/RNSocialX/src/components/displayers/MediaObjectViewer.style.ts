import { StyleSheet } from 'react-native';

const styles = {
	image: {
		width: '100%',
		height: '100%',
	},
};

export default StyleSheet.create(styles);

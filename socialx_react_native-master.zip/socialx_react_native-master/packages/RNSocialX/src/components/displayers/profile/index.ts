export { Profile } from './Profile';
export { Statistics } from './Statistics';
export { Tabs } from './Tabs';
export { Friends } from './Friends';
export { Avatar } from './Avatar';

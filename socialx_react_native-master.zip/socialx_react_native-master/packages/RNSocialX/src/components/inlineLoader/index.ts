export { WithInlineLoader, IWithLoaderProps } from './WithInlineLoader';
export { SpinnerTypes } from './SpinKitLoader';

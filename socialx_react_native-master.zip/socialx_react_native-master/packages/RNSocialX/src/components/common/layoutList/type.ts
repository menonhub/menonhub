export interface LayoutListItemData {
	title: string;
	description: string;
}

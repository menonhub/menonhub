import { LayoutGridListItemData } from '../layoutGridList';
import { LayoutListItemData } from '../layoutList';

export type LayoutMenuItemData = LayoutGridListItemData & LayoutListItemData;

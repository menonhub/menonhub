// leave off @2x/@3x
export const Images = {
	launch: require('./assets/images/launch_screen_bg.png'),
	unlock_key: require('./assets/images/unlock_key.png'),
	user_avatar_placeholder: require('./assets/images/user_avatar_placeholder.png'),
	IntroWalkThrough1: require('./assets/images/WalkThrough1.png'),
	IntroWalkThrough1Logo: require('./assets/images/WalkThrough1Logo.png'),
	IntroWalkThrough2: require('./assets/images/WalkThrough2.png'),
	IntroWalkThrough3: require('./assets/images/WalkThrough3.png'),
};
